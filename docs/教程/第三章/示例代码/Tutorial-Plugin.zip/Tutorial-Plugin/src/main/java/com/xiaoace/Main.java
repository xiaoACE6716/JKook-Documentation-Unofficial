package com.xiaoace;

import com.xiaoace.commands.AllTheCommands;
import com.xiaoace.listeners.VoiceChannelListener;
import snw.jkook.command.JKookCommand;
import snw.jkook.plugin.BasePlugin;

public class Main extends BasePlugin {

    private static Main INSTANCE;

    public static Main getInstance() {
        return INSTANCE;
    }

    @Override
    public void onLoad() {
        saveDefaultConfig();

        //让实例指向这个插件
        INSTANCE = this;
    }

    @Override
    public void onEnable() {

        // 注册命令
        AllTheCommands commands = new AllTheCommands(INSTANCE,getLogger());
        getCore().getCommandManager().registerCommand(this,commands.getMyScore());
        getCore().getCommandManager().registerCommand(this,commands.getEditScore());

        // 注册监听器

        getCore().getEventManager().registerHandlers(this,new VoiceChannelListener());
    }

}
