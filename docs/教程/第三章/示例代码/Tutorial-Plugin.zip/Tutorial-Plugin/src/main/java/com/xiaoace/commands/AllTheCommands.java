package com.xiaoace.commands;

import lombok.Getter;
import org.slf4j.Logger;
import snw.jkook.command.JKookCommand;
import snw.jkook.config.file.FileConfiguration;
import snw.jkook.plugin.Plugin;

public class AllTheCommands {

    Plugin plugin;
    Logger logger;
    FileConfiguration config;

    @Getter
    JKookCommand myScore;
    @Getter
    JKookCommand editScore;


    public AllTheCommands(Plugin plugin, Logger logger) {

        this.plugin = plugin;
        this.logger = logger;
        config = plugin.getConfig();

        myScore = new JKookCommand("myScore", "/")
                .setDescription("用途: 查询个人积分。")
                .setHelpContent("用途: 查询个人积分。")
                .executesUser((sender, arguments, message) -> {

                    // 没有写数据库捏 所以随便写一下了
                    message.reply("你有"+ Math.random()*100 +"积分");

                });

        editScore = new JKookCommand("editScore", "/")
                .setDescription("用途: 修改用户积分。")
                .setHelpContent("用途: 修改用户积分。")
                .executesUser((sender, arguments, message) -> {

                    // 没有写数据库捏 所以随便写一下了
                    // 此处应有操作数据的代码

                    message.reply("修改完毕");

                });

    }

}
