package com.xiaoace.listeners;

import com.xiaoace.utils.VoiceChannelTracker;
import snw.jkook.entity.channel.TextChannel;
import snw.jkook.event.EventHandler;
import snw.jkook.event.Listener;
import snw.jkook.event.user.UserJoinVoiceChannelEvent;
import snw.jkook.event.user.UserLeaveVoiceChannelEvent;

import static com.xiaoace.Main.getInstance;

public class VoiceChannelListener implements Listener {

    VoiceChannelTracker tracker = new VoiceChannelTracker();

    @EventHandler
    public void joinVoiceChannelEvent(UserJoinVoiceChannelEvent event) {

        String userName = event.getUser().getFullName(null);
        String userID = event.getUser().getId();
        long timestamp = event.getTimeStamp();

        tracker.userJoined(userID,timestamp);

    }

    @EventHandler
    public void leaveVoiceChannel(UserLeaveVoiceChannelEvent event) {

        String userName = event.getUser().getFullName(null);
        String userID = event.getUser().getId();
        long timestamp = event.getTimeStamp();

        long duration = tracker.userLeft(userID,timestamp);

        ((TextChannel)getInstance().getCore().getHttpAPI().getChannel(getInstance().getConfig().getString("channel")))
                .sendComponent(userName + "在语音频道: " + event.getChannel().getName() + "待了: " + duration + " milliseconds");

    }

}
