package com.xiaoace.utils;

import java.util.HashMap;
import java.util.Map;

public class VoiceChannelTracker {

    private Map<String, Long> timestamps;

    public VoiceChannelTracker() {
        timestamps = new HashMap<>();
    }

    public void userJoined(String userId, long timestamp) {
        timestamps.put(userId, timestamp);
    }

    public long userLeft(String userId, long timestamp) {

        long joinTimestamp = timestamps.getOrDefault(userId, 0L);

        if ( joinTimestamp == 0L ) {
            return 0L;
        }

        long duration = timestamp - joinTimestamp;

        timestamps.remove(userId);
        return duration;
    }

}
